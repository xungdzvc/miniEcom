package com.web;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;

@SpringBootApplication
@EnableRetry
@Slf4j   
public class MiniECommerceApplication { 
	public static void main(String[] args) {
		SpringApplication.run(MiniECommerceApplication.class, args);
	}

}
