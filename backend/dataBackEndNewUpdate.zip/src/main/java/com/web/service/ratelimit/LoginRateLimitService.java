package com.web.service.ratelimit;

import io.github.bucket4j.Bucket;
import io.github.bucket4j.Bandwidth;
import lombok.RequiredArgsConstructor;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
@RequiredArgsConstructor
public class LoginRateLimitService {

    private static final int MAX_ATTEMPTS = 5;
    private static final Duration WINDOW = Duration.ofMinutes(5);

    private final StringRedisTemplate redisTemplate;

    public boolean isBlocked(String ip, String username){
        String key = buildKey(ip,username);
        String value = redisTemplate.opsForValue().get(key);
        if(value == null){
            return false;
        }
        return Integer.parseInt(value) >= MAX_ATTEMPTS;
    }

    private String buildKey(String ip, String username){
        String normalizedUsename = username == null ? "uknown" : username.trim().toLowerCase();
        return "rate-limit:login" + ip + ":" + normalizedUsename;
    }

    public void loginFailed(String ip, String username){
        String key = buildKey(ip,username);
        Long attempts =
                redisTemplate.opsForValue().increment(key);

        if(attempts != null && attempts == 1){
            redisTemplate.expire(key,WINDOW);
        }
    }
    public void loginSuccess(String ip, String username){
        String key = buildKey(ip,username);
        redisTemplate.delete(key);
    }




























    private final Map<String, Bucket> cache =
            new ConcurrentHashMap<>();

    public Bucket resolveBucket(String ip) { 
        return cache.computeIfAbsent(ip, this::newBucket);
    }

    private Bucket newBucket(String ip) {

        Bandwidth limit = Bandwidth.builder()
                .capacity(60)
                .refillGreedy(60, Duration.ofMinutes(1))
                .build();

        return Bucket.builder()
                .addLimit(limit)
                .build();
    }
}