package com.web.repository;

import com.web.entity.ProductDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ProductDetailRepository extends JpaRepository<ProductDetailEntity,Long> {
    @Query("""
            update ProductDetailEntity pd 
            set pd.quantity = pd.quantity - :quantity
            where pd.id = :ProductDetailEntityId
            """)
    int reserveStock(@Param("ProductDetailEntityId") Long productId, @Param("quantity") Integer quantity);

    @Query("""
            update ProductDetailEntity pd 
            set pd.quantity = pd.quantity + :quantity
            where pd.id = :ProductDetailEntityId
            """)
    int releaseStock(@Param("ProductDetailEntityId") Long productId, @Param("quantity") Integer quantity);

}
