package com.web.service.ratelimit;

import io.github.bucket4j.Bucket;
import io.github.bucket4j.Bandwidth; 
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class LoginRateLimitService {

    private final Map<String, Bucket> cache =
            new ConcurrentHashMap<>();

    public Bucket resolveBucket(String ip) { 
        return cache.computeIfAbsent(ip, this::newBucket);
    }

    private Bucket newBucket(String ip) {

        Bandwidth limit = Bandwidth.builder()
                .capacity(60)
                .refillGreedy(60, Duration.ofMinutes(1))
                .build();

        return Bucket.builder()
                .addLimit(limit)
                .build();
    }
}